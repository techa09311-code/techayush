// IMPORTANT: Replace this with a safe business email address before publishing.
const CONTACT_EMAIL = "techa09311@gamil.com"

const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav-links");

menuButton.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
  menuButton.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuButton.textContent = isOpen ? "✕" : "☰";
});

nav.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.textContent = "☰";
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("contactForm").addEventListener("submit", event => {
  event.preventDefault();
  if (CONTACT_EMAIL.includes("YOUR_BUSINESS_EMAIL")) {
    document.getElementById("formNote").textContent =
      "Setup needed: open script.js and replace YOUR_BUSINESS_EMAIL@example.com with your business email. Then this form will prepare an email.";
    return;
  }

  const data = new FormData(event.currentTarget);
  const subject = encodeURIComponent(`Website enquiry from ${data.get("name")}`);
  const body = encodeURIComponent(
    `Name: ${data.get("name")}\nEmail: ${data.get("email")}\nService: ${data.get("service")}\n\nProject details:\n${data.get("message")}`
  );
  window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
});