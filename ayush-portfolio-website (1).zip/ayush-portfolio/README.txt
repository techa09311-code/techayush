AYUSH PORTFOLIO WEBSITE
======================

FILES
- index.html : page structure and content
- style.css  : responsive dark-tech visual design
- script.js  : mobile navigation and contact-form email draft

RUN LOCALLY
1. Extract the ZIP file.
2. Open the folder in VS Code.
3. Open index.html in a browser (or use the Live Server extension).

BEFORE PUBLISHING
1. Open script.js and replace YOUR_BUSINESS_EMAIL@example.com with a safe business email address you control.
2. Update the sample project cards with real projects. The current cards are clearly marked as concepts.
3. Review the text and services so they accurately describe what you offer.
4. Do not publish a personal phone number or exact home address. Use a business contact channel and broad location only.

CONTACT FORM
The form uses mailto: and opens the visitor's email application. It does not store or send data to a server. A real hosted form/backend can be added later.

DESIGN
Inspired by the general SaaS/tech-consulting direction of the references supplied by the user; this is an original layout, not a copy.
